#pragma once

#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64.hpp"

class SineWaveSubscriber : public rclcpp::Node
{
public:
    SineWaveSubscriber();

private:
    void topic_callback(const std_msgs::msg::Float64::SharedPtr msg);
    
    
    rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr subscription_;

};