#pragma once

#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64.hpp"

class SineWavePublisher : public rclcpp::Node
{
public:
    SineWavePublisher();

private:
    void timer_callback();

    rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr publisher_;

    
    rclcpp::TimerBase::SharedPtr timer_;


    double a_;
    double w_;
    double alpha_;
    
    rclcpp::Time start_time_;
};