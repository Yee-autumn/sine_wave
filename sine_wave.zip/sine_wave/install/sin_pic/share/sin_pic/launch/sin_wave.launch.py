import os
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg_path = get_package_share_directory('sin_pic')

    #  配置文件路径
    default_config_path = os.path.join(pkg_path, 'config', 'config_file.yaml')
    
    config_path_arg = DeclareLaunchArgument(
        'config_file',
        default_value=default_config_path,
        description='Path to the configuration file'
    )
    
    # 发布者节点
    pub_node = Node(
        package='sin_pic',
        executable='sin_pub',
        name='sine_publisher',
        output='screen',
        parameters=[LaunchConfiguration('config_file')]  
    )
    
    # 订阅者节点
    sub_node = Node(
        package='sin_pic',
        executable='sin_sub',
        name='sine_subscriber',
        output='screen'
    )
    
    return LaunchDescription([
        config_path_arg,
        pub_node,
        sub_node
    ])