# generated from ament/cmake/core/templates/nameConfig.cmake.in

# prevent multiple inclusion
if(_sin_pic_CONFIG_INCLUDED)
  # ensure to keep the found flag the same
  if(NOT DEFINED sin_pic_FOUND)
    # explicitly set it to FALSE, otherwise CMake will set it to TRUE
    set(sin_pic_FOUND FALSE)
  elseif(NOT sin_pic_FOUND)
    # use separate condition to avoid uninitialized variable warning
    set(sin_pic_FOUND FALSE)
  endif()
  return()
endif()
set(_sin_pic_CONFIG_INCLUDED TRUE)

# output package information
if(NOT sin_pic_FIND_QUIETLY)
  message(STATUS "Found sin_pic: 0.1.0 (${sin_pic_DIR})")
endif()

# warn when using a deprecated package
if(NOT "" STREQUAL "")
  set(_msg "Package 'sin_pic' is deprecated")
  # append custom deprecation text if available
  if(NOT "" STREQUAL "TRUE")
    set(_msg "${_msg} ()")
  endif()
  # optionally quiet the deprecation message
  if(NOT sin_pic_DEPRECATED_QUIET)
    message(DEPRECATION "${_msg}")
  endif()
endif()

# flag package as ament-based to distinguish it after being find_package()-ed
set(sin_pic_FOUND_AMENT_PACKAGE TRUE)

# include all config extra files
set(_extras "")
foreach(_extra ${_extras})
  include("${sin_pic_DIR}/${_extra}")
endforeach()
