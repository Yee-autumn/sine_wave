#include <chrono>
#include <cmath>
#include <stdexcept>
#include <string>
#include "sin_pic/sin_pub.hpp"

#include "rclcpp/rclcpp.hpp"


SineWavePublisher::SineWavePublisher()
: Node("sine_publisher"), start_time_(this->now())
{
    // 声明参数
    this->declare_parameter<double>("pub_freq",1.0);
    this->declare_parameter<double>("a",1.0);
    this->declare_parameter<double>("w",1.0);
    this->declare_parameter<double>("alpha",1.0);

    // 获取参数
    double freq = this->get_parameter("pub_freq").as_double();
    double a = this->get_parameter("a").as_double();
    double w = this->get_parameter("w").as_double();
    double alpha = this->get_parameter("alpha").as_double();

    a_=a;
    w_=w;
    alpha_ = alpha;


    // 计算定时周期，用于定时器
    auto period =std::chrono::milliseconds(static_cast<int>(1000.0/freq));


    //创建发布方
    publisher_ = this->create_publisher<std_msgs::msg::Float64>("sine_wave", 10);
    RCLCPP_INFO(this->get_logger(),"create sin publisher");

    timer_=this->create_wall_timer(period,std::bind(&SineWavePublisher::timer_callback,this));

};


void SineWavePublisher::timer_callback()
{
    auto message = std_msgs::msg::Float64();
    const double t = (this->now() - start_time_).seconds();
    message.data = a_*sin(w_*t+alpha_);
     publisher_->publish(message);
    RCLCPP_INFO(this->get_logger(),"%f",message.data);


}

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<SineWavePublisher>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
