#include <string>
#include <functional>

#include "sin_pic/sin_sub.hpp"

SineWaveSubscriber::SineWaveSubscriber()
: Node("sine_subscriber")
{
    subscription_=this->create_subscription<std_msgs::msg::Float64>("sine_wave",10,std::bind(&SineWaveSubscriber::topic_callback,this,std::placeholders::_1));
    RCLCPP_INFO(this->get_logger(),"create sin subscription");

}

void SineWaveSubscriber::topic_callback(const std_msgs::msg::Float64::SharedPtr msg)
{
    // 日志，在终端输出信息
    RCLCPP_INFO(this->get_logger(),"%f",msg->data);
}

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<SineWaveSubscriber>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
